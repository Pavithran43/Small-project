import React from "react";
import {AiFillTwitterCircle,AiFillLinkedin} from "react-icons/ai";
import {BsFacebook} from "react-icons/bs";
import {RiInstagramFill} from "react-icons/ri";

const Footer=()=>{
    return(
        <div>
            <footer className="box-Items">
                <div className="container flex">
                    <p>Carts Ecommerce-All  right reserved-Design & Developed by RedQ,Inc</p>
                    <div className="social">
                        <BsFacebook className="icon" />
                        <AiFillTwitterCircle className="icon" />
                        <AiFillLinkedin className="icon"/>
                        <RiInstagramFill className="icon"/>

                    </div>
                </div>
            </footer>


        </div>
    )
}

export default Footer;
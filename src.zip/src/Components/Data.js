const DATA=[
    {
    id:0,
    title:"Apple Laptop",
    price:40000,
    desc:"A laptop has an all-in-one design, with a built-in monitor, keyboard, touchpad (whichreplaces the mouse), and speakers. This means it is fully functional, even when no peripherals are connected. A laptop is also quicker to set up, and there are fewer cables to get in the way.",
    img:"../image/iphonelap.jpg"
},
{

    id:1,
    title:"Hp Laptop",
    price:60000,
    desc:"A laptop has an all-in-one design, with a built-in monitor, keyboard, touchpad (whichreplaces the mouse), and speakers. This means it is fully functional, even when no peripherals are connected. A laptop is also quicker to set up, and there are fewer cables to get in the way.",
    img:"../image/lapimage3.jpg"
},
{
    id:2,
    title:"Apple Laptop",
    price:40000,
    desc:"A laptop has an all-in-one design, with a built-in monitor, keyboard, touchpad (whichreplaces the mouse), and speakers. This means it is fully functional, even when no peripherals are connected. A laptop is also quicker to set up, and there are fewer cables to get in the way.",
    img:"../image/iphonelap4.jpg"

},

{
    id:3,
    title:"Apple Laptop",
    price:40000,
    desc:"A laptop has an all-in-one design, with a built-in monitor, keyboard, touchpad (whichreplaces the mouse), and speakers. This means it is fully functional, even when no peripherals are connected. A laptop is also quicker to set up, and there are fewer cables to get in the way.",
    img:"../image/Newlaptop.jpg"

}

]

export default DATA;
import addItem from "./addItemss";
import {combineReducers} from "redux";

const rootReducers=combineReducers({
    addItem
})

export default rootReducers;